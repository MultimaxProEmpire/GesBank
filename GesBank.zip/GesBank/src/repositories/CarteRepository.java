package src.repositories;

import java.util.List;
import java.util.ArrayList;
import src.entities.CarteGap;

public class CarteRepository {
    List<CarteGap> carteGap = new ArrayList<>();

    public CarteRepository(){
        initListCarte();
    }

    public void initListCarte(){
        carteGap.add(new CarteGap("3456-9032-1244-2355"));
        carteGap.add(new CarteGap("2819-4201-3689-9553"));
        carteGap.add(new CarteGap("1221-5700-4532-5612"));
    }

    public List<CarteGap> findAll(){
        return carteGap;
    }
    public CarteGap findByNumero(String num){
        return carteGap
        .stream()
        .filter(a->a.getNumero().compareTo(num)==0)
        .findFirst()
        .orElse(null)
        ;
    }

}
