package src.repositories;

//Repositories = unite de stockage de donnee elle definie ou sont stocker les donnee (DAO)

import java.util.List;
import java.util.ArrayList;
import src.entities.Agence;

public class AgenceRepository {
    List<Agence> agences = new ArrayList<>();
    public AgenceRepository(){
        initListAgence();
    } 
    public void initListAgence(){
        agences.add(new Agence("Point E","33-860-10-10"));
        agences.add(new Agence("Fass","33-860-10-11"));
        agences.add(new Agence("Colobane","33-860-10-12"));


    }

    public List<Agence> findAll(){
        return agences;
    } 

    public Agence insert(Agence agence){
        agences.add(agence);
        return agence;
    }

    public Agence findByNumero(String num){
        return agences
        .stream()
        .filter(a->a.getNumero().compareTo(num)==0)
        .findFirst()
        .orElse(null)
        ;


    }
    
    

}
