package src.repositories;

import java.util.ArrayList;
import src.entities.Client;
import java.util.List;
public class ClientRepository {
    List<Client> clients = new ArrayList<>();
    

    public Client Save(Client client){
        clients.add(client);
        return client;
    }

    public Client findByTelephone(String tel){
        return clients
        .stream()
        .filter(a->a.getTel().compareTo(tel)==0)
        .findFirst()
        .orElse(null)
        ;
    }
}
