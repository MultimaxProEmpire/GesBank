package src.repositories;

import java.util.List;
import java.util.ArrayList;
import src.entities.Compte;
import src.entities.Cheque;
import src.entities.Epargne;

public class CompteRepository {
    List<Compte> comptes = new ArrayList<>();
    public CompteRepository(){
        initListCompte();
    }

    public void initListCompte(){
        comptes.add(new Cheque(5000000,2500)); 
        comptes.add(new Epargne(30000000,10)); 
        comptes.add(new Cheque(50000445,3500)); 
    }
    public List<Compte> findAll(){
        return comptes;
    }
    public Compte Save(Compte compte){
        comptes.add(compte);
        return compte;
    }
    public Compte findByNumero(String num){
        return comptes
        .stream()
        .filter(a->a.getNumero().compareTo(num)==0)
        .findFirst()
        .orElse(null)
        ;
    }
    

 }

