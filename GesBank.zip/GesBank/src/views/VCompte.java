package src.views;

import java.util.Scanner;

import src.services.BanqueService;
import src.entities.Cheque;
import src.entities.Client;
import src.entities.Compte;
import src.entities.Epargne;
import src.entities.Agence;
import src.entities.CarteGap;
public class VCompte {

    public static void menu(){
        Scanner clavier = new Scanner(System.in);
        BanqueService banqueService = new BanqueService();

        int choix;
         do{
            System.out.println("1- Lister les Comptes ");
            System.out.println("2- Ajouter un Compte");
            System.out.println("3- Lister compte d'un client ");
            System.out.println("4- Affecter une carte à un compte");
            System.out.println("   Faites votre choix !");
            choix=clavier.nextInt();
            switch(choix){
                case 1:
                    banqueService.listerCompte().forEach(System.out::println);  
                    break;
                    
                case 2:
                    System.out.println("Information du client");
                    System.out.println("Entrer le telephone");
                    String tel=clavier.next();
                    Client client = banqueService.rechercherClient(tel);
                    if(client==null){
                        System.out.println("Entrer le nom complet:");
                        String nomComplet = clavier.next();
                         client = new Client(tel, nomComplet);
                        banqueService.ajouterClient(client);
                    }
                    System.out.println("Information du compte");
                    System.out.println("Entrer le solde du compte");
                    double solde = clavier.nextDouble();
                    int type;
                    System.out.println("Entrer le type de compte");

                    do{
                        System.out.println("1-Epargne\n2-Cheque");
                        type=clavier.nextInt();

                    }while(type!=1 && type!=2);
                        Compte compte;
                        if(type==1){
                            System.out.println("Entrer le taux");
                            int taux = clavier.nextInt();
                             compte = new Epargne(solde, taux);
                        }else{
                            System.out.println("Entrer les frais");
                            int frais = clavier.nextInt();
                             compte = new Cheque(solde, frais);
                        }
                        Agence agence;
                        
                            do{
                                System.out.println("Information de l'agence");
                                banqueService.listerAgence().forEach(System.out::println);
                                System.out.println("Entrer le numero");
                                String num = clavier.next();
                                agence = banqueService.rechercherAgence(num);

                            }while(agence==null);
                            compte.setClient(client);
                            compte.setAgence(agence);
                            banqueService.ajouterCompte(compte);

                    break;
                case 3:
                    System.out.println("Entrer le telephone");
                    tel = clavier.next();
                    client = banqueService.rechercherClient(tel);
                    if(client!=null){
                        client.getTabCompte().forEach(System.out::println);
                    }

                    break;
                case 4:
                    System.out.println("Entrer le numero de Compte");
                    String num = clavier.next();
                    compte=banqueService.rechercherCompte(num);
                    if(compte!=null){
                        System.out.println("Choisir une carte");
                        banqueService.listerCarte().forEach(System.out::println);
                        num = clavier.next();
                        CarteGap carte = banqueService.rechercherCarte(num);
                        if(carte!=null){
                            compte.setCarteGap(carte);
                        }
                    }
                    break;
                default:
                    break;
            }

         }while(choix!=5);
            clavier.close();
    }
}
