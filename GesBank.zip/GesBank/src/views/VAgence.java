package src.views;
import src.services.BanqueService;
import src.entities.Agence;
import java.util.Scanner;

public class VAgence {

    public static void menu(){
        Scanner clavier = new Scanner(System.in);

        BanqueService banqueService = new BanqueService();
        int choix;

        do{
            System.out.println(" 1- Lister ");
            System.out.println(" 2- Ajouter ");
            System.out.println(" 3- Rechercher ");
            System.out.println(" 4- Quitter ");
            System.out.println(" Faites votre choix ! ");

            choix=clavier.nextInt();
            
            switch(choix){
                case 1:
                    banqueService.listerAgence().forEach(System.out::println);
                    break;
                case 2:
                    System.out.println("Entrer le telephone : ");
                    String tel = clavier.next();
                    System.out.println("Entrer l'adresse : ");
                    String adresse = clavier.next();
                    System.out.println();
                    Agence agence = new Agence();
                    agence.setAdresse(adresse);
                    agence.setTel(tel);
                    banqueService.ajouterAgence(agence);
                    break;
                case 3:
                    System.out.println("Entrer le numero : ");
                    String num=clavier.nextLine();
                    System.out.println();
                    Agence ag = banqueService.rechercherAgence(num);
                    if(ag==null){
                        System.out.println("Cette agence n'existe pas");
                    }else{
                        System.out.println(ag);
                    }

                case 4:
                default:
                    break;
            }
        }while(choix != 4);
            clavier.close();
            
 
    }
}
