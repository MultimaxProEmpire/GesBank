package src.entities;

public class Epargne extends Compte{
    private int taux;
    
    public Epargne(){
        taux=10;
        type="Epargne";
    }
    public Epargne(double solde,int taux){
        type="Epargne";
        this.solde=solde;
        this.taux=taux;

    }

    public int getTaux() {
        return taux;
    }

    public void setTaux(int taux) {
        this.taux = taux;
    }

    @Override
    public String toString() {
        return "Epargne ["+super.toString()+", frais=" + taux + "]";
    }

    
}
