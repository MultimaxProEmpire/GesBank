package src.entities;

public class Cheque extends Compte{
    private int frais;
    private CarteGap carteGap;

    public Cheque(){
        type="Cheque";
        frais=5000;

    }
    public Cheque(double solde,int frais){
        this.solde=solde;
        this.frais=frais;
        type="Cheque";
      
    }
    public int getFrais() {
        return frais;
    }

    public void setFrais(int frais) {
        this.frais = frais;
    }
    public CarteGap getCarteGap() {
        return carteGap;
    }
    public void setCarteGap(CarteGap carteGap) {
        this.carteGap = carteGap;
    }
    @Override
    public String toString() {
        return "Cheque ["+super.toString()+", taux=" + frais+carteGap+" ]";
    } 
    
}
