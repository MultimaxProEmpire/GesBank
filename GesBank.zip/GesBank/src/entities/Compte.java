package src.entities; 

public class Compte {
    
    public static int nbre;
    protected int id;
    protected String numero;
    protected double solde;
    protected String type;
    protected Client client;
    protected Agence agence;
    protected CarteGap carteGap;


    public Compte() {
        nbre++;
        id = nbre;
        numero = "cpt"+nbre;
        solde = 0;
    }

    public Compte(double solde) {
        this.solde=solde;
        nbre++;
        id = nbre;
        numero = "cpt"+nbre;
        solde = 0;
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getNumero() {
        return numero;
    }
    public void setNumero(String numero) {
        this.numero = numero;
    }
    
    public double getSolde() {
        return solde;
    }
    public void setSolde(double solde) {
        this.solde = solde;
    }

    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
        client.setTabCompte(this);
    }

    public Agence getAgence() {
        return agence;
    }

    public void setAgence(Agence agence) {
        this.agence = agence;
    }

    public CarteGap getCarteGap() {
        return carteGap;
    }

    public void setCarteGap(CarteGap carteGap) {
        this.carteGap = carteGap;
    }


    @Override
    public String toString() {
        return " [id=" + id + ", numero=" + numero + ", solde=" + solde + ", type=" + type+" ] "+client;
    }
}



