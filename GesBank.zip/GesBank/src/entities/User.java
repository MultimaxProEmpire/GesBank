package src.entities;

public class User {
    public static int nbre;
    protected int id;
    protected String role;
    protected String login;
    protected String password;
    protected String nomComplet;
    
    public User() {
        nbre++;
        id=nbre;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }
    public String getLogin() {
        return login;
    }
    public void setLogin(String login) {
        this.login = login;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getNomComplet() {
        return nomComplet;
    }
    public void setNomComplet(String nomComplet) {
        this.nomComplet = nomComplet;
    }

    @Override
    public String toString() {
        return " [id=" + id + ", login=" + login + ", nomComplet=" + nomComplet + ", password=" + password
                + ", role=" + role + "]";
    }


    
}
