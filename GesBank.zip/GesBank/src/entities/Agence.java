package src.entities;

import java.util.ArrayList;

public class Agence {
    public static int nbre;
    private int id;
    private String numero;
    private String adresse;
    private String tel;
    public ArrayList<Compte> tabCompteA = new ArrayList<>();
    // Contructeur par defaut 
    public Agence() {
        nbre++;
        id=nbre;
        numero="AG_"+nbre;
    }

    //Surcharge ou Polimorphisme Parametrique
    // Surchage d'insertion 
    public Agence(String adresse,String tel){
        this.adresse=adresse;
        this.tel=tel;
        nbre++;
        id=nbre;
        numero="AG_"+nbre;
    }


    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getNumero() {
        return numero;
    }
    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getAdresse() {
        return adresse;
    }
    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getTel() {
        return tel;
    }
    public void setTel(String tel) {
        this.tel = tel;
    }
    public ArrayList<Compte> getTabCompte() {
        return tabCompteA;
    }

    public void setTabCompte(Compte compte) {
        tabCompteA.add(compte);
    }

    //Serialisation ou ToString methode 
    @Override
    public String toString() {
        return "Agence [adresse=" + adresse + ", id=" + id + ", numero=" + numero + ", tel=" + tel + "]";
    }
    
}
