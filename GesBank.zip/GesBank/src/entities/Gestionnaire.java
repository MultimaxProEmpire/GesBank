package src.entities;

public class Gestionnaire extends User {

    public Gestionnaire() {
        this.role="Gestionnaire";
    }

    @Override
    public String toString() {
        return "Gestionnaire "+super.toString();
    }
    
}
