package src.entities;

import java.util.ArrayList;

public class CarteGap {
    public static int nbre;
    private int id;
    private String numero;
    private String dateExp;
    public ArrayList<Cheque> cheque = new ArrayList<>();
    
    
    
    
    public CarteGap() {
        nbre++;
        id=nbre;
    }
    public CarteGap(String numero){
        this.numero = numero;
        nbre++;
        id=nbre;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNumero() {
        return numero;
    }
    public void setNumero(String numero) {
        this.numero = numero;
    }
    public String getDateExp() {
        return dateExp;
    }
    public void setDateExp(String dateExp) {
        this.dateExp = dateExp;
    }

    public ArrayList<Cheque> getCheque() {
        return cheque;
    }
    public void setCheque(Cheque cheques) {
        cheque.add(cheques);
    }
   
    
    @Override
    public String toString() {
        return "CarteGap [dateExp=" + dateExp + ", id=" + id + ", numero=" + numero + "]";
    }


}
