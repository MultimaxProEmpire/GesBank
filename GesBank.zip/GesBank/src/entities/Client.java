package src.entities;
import java.util.ArrayList;

public class Client extends User{
    private String tel;
    public ArrayList<Compte> tabCompte = new ArrayList<>();
   
    public Client(String tel,String nomComplet) {
        role="Client";
        this.tel = tel;
        this.nomComplet = nomComplet;

    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public ArrayList<Compte> getTabCompte() {
        return tabCompte;
    }

    public void setTabCompte(Compte compte) {
        tabCompte.add(compte);
    }



    @Override
    public String toString() {
        return "Client ["+super.toString()+"tel=" + tel + "]";
    }


    
    
}
