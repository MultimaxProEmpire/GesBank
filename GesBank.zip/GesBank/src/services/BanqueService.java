package src.services;

import src.entities.Agence;
import src.entities.CarteGap;
import src.entities.Compte;
import src.entities.Client;
import java.util.List;
import src.repositories.AgenceRepository;
import src.repositories.CarteRepository;
import src.repositories.ClientRepository;
import src.repositories.CompteRepository;

//Findall dans AgenceRepositories est une methode d'instance donc on creer un objet de type repositories

public class BanqueService {

    AgenceRepository agenceRepository = new AgenceRepository();
    CompteRepository compteRepository = new CompteRepository();
    ClientRepository clientRepository = new ClientRepository();
    CarteRepository  carteRepository = new CarteRepository();

    public List<Agence> listerAgence(){

        return agenceRepository.findAll();
    }

    public Agence ajouterAgence(Agence agence){

        return agenceRepository.insert(agence);
    }

    public Agence rechercherAgence(String num){
        return agenceRepository.findByNumero(num);
    }
    
    public List<Compte> listerCompte(){
        return compteRepository.findAll();
    }
    public Boolean ajouterCompte(Compte compte){
        return compteRepository.Save(compte)!=null;
    }
    public List<Compte> listerCompteUnClient(String tel){
        return compteRepository.findAll();
    }
    public Compte rechercherCompte(String num){
        return compteRepository.findByNumero(num);
    }

    public Client rechercherClient(String tel){
        return clientRepository.findByTelephone(tel);
    }
    public Client ajouterClient(Client client){
        return clientRepository.Save(client);
    }

    public List<CarteGap> listerCarte(){
        return carteRepository.findAll();
    }
    public CarteGap rechercherCarte(String num){
        return carteRepository.findByNumero(num);
    }
    
}
